/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2024 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "cmsis_os.h"
#include "lwip.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include "i2c_driver_dac.h"
#include "lwip/udp.h"
#include "lwip/raw.h"
#include "string.h"
#include "stdbool.h"
#include "lwip/pbuf.h"
#include "lwip/ip_addr.h"
#include "FreeRTOS.h"
#include "queue.h"
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */

/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */
#define __ATTR_SAI_DMA1   __attribute__ ((section(".SAIbuffer"))) __attribute__ ((aligned (4)))

#define NSAMPLE 8

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/

I2C_HandleTypeDef hi2c3;

SAI_HandleTypeDef hsai_BlockA1;
DMA_HandleTypeDef hdma_sai1_a;

TIM_HandleTypeDef htim12;

/* Definitions for Main_task */
osThreadId_t Main_taskHandle;
const osThreadAttr_t Main_task_attributes = {
  .name = "Main_task",
  .stack_size = 1024 * 4,
  .priority = (osPriority_t) osPriorityNormal,
};
/* USER CODE BEGIN PV */
QueueHandle_t DACQueue ;

int32_t DAC[NSAMPLE*16]__ATTR_SAI_DMA1 ;
extern struct netif gnetif; // network interface
bool sending_enabled=0;
struct udp_pcb *pcb_ack=NULL;
struct pbuf *p_out=NULL;
uint16_t type=0;

/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
static void MPU_Config(void);
static void MX_GPIO_Init(void);
static void MX_DMA_Init(void);
static void MX_I2C3_Init(void);
static void MX_SAI1_Init(void);
static void MX_TIM12_Init(void);
void StartMainTask(void *argument);

/* USER CODE BEGIN PFP */
void I2C_set_clock(uint8_t fs_case);
void I2C_init_dac(int addr);
void I2C_set_gain_dac(int addr,uint8_t channel,uint8_t value);
bool packet_check(uint8_t* in,uint8_t* out);

/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */


bool packet_check(uint8_t* in,uint8_t* out){
	bool ret=1;
	//header id: ETH8DAC
	if(in[14] != 69 || in[15] !=  84  || in[16] != 72 || in[17] != 56 || in[18] != 68 || in[19] !=  65 || in[20] != 67 )
	{
		ret=0;
		return ret;
	}

	if(memcmp(in+6,out,6)!=0){
		memcpy(out,in+6,6);
		memcpy(out+6,gnetif.hwaddr, 6);
		memcpy(out + 12, &type, 2);  // EtherType field
		ret=0;
	}

	//clock case
	if(in[21]!=out[21])
	{
		ret=0;
		xQueueReset(DACQueue);
		HAL_SAI_Abort(&hsai_BlockA1);
		I2C_set_clock(in[21]);
		HAL_SAI_Transmit_DMA(&hsai_BlockA1, (uint8_t*)DAC, NSAMPLE*16);
	}

	if(in[22]!=out[22])
	{
		ret=0;
		HAL_SAI_Abort(&hsai_BlockA1);

		vQueueDelete(DACQueue);
		if(in[22]!=8 || in[22]!= 16){
			DACQueue=xQueueCreate(in[22],NSAMPLE*32);
		}else{
			DACQueue=xQueueCreate(4,NSAMPLE*32);
		}
		xQueueReset(DACQueue);
		I2C_set_clock(in[21]);
		HAL_SAI_Transmit_DMA(&hsai_BlockA1, (uint8_t*)DAC, NSAMPLE*16);
	}

	//gain dac
	if(in[23]!=out[23])
	{
		ret=0;
		I2C_set_gain_dac(dac1_addr,1,in[23]);
	}
	if(in[24]!=out[24])
	{
		ret=0;
		I2C_set_gain_dac(dac1_addr,2,in[24]);
	}
	if(in[25]!=out[25])
	{
		ret=0;
		I2C_set_gain_dac(dac2_addr,1,in[25]);
	}
	if(in[26]!=out[26])
	{
		ret=0;
		I2C_set_gain_dac(dac2_addr,2,in[26]);
	}
	if(in[27]!=out[27])
	{
		ret=0;
		I2C_set_gain_dac(dac3_addr,1,in[27]);
	}
	if(in[28]!=out[28])
	{
		ret=0;
		I2C_set_gain_dac(dac3_addr,2,in[28]);
	}
	if(in[29]!=out[29])
	{
		ret=0;
		I2C_set_gain_dac(dac4_addr,1,in[29]);
	}
	if(in[30]!=out[30])
	{
		ret=0;
		I2C_set_gain_dac(dac4_addr,2,in[30]);
	}

	//copy header if change
	if(!ret)
	{
		memcpy(out+14,in+14,50);
		ret=1;
	}

	return ret;
}

void I2C_set_gain_dac(int addr,uint8_t channel,uint8_t value){
	uint8_t command[2];
	command[0]=0;
	command[1]=0;
	HAL_I2C_Master_Transmit(&hi2c3,addr,command,dac_command_lenght,HAL_MAX_DELAY);
	if(value!=255){
		//channel 1,2
		command[0]=dac[channel+36].address;
		command[1]=160-(value*2);
		HAL_I2C_Master_Transmit(&hi2c3,addr,command,dac_command_lenght,HAL_MAX_DELAY);
	}else{
		command[0]=dac[channel+36].address;
		command[1]=value;
		HAL_I2C_Master_Transmit(&hi2c3,addr,command,dac_command_lenght,HAL_MAX_DELAY);
	}
}

void I2C_init_dac(int addr){
	uint8_t command[2]={0};
	for(int i=0;i<dac_num_registers;i++){
		command[0]=dac[i].address;
		command[1]=dac[i].value;
		if(addr==dac2_addr && command[0]==0x29){command[1]=64;}
		if(addr==dac3_addr && command[0]==0x29){command[1]=128;}
		if(addr==dac4_addr && command[0]==0x29){command[1]=192;}
		HAL_I2C_Master_Transmit(&hi2c3,addr,command,dac_command_lenght,HAL_MAX_DELAY);
	}
}

void I2C_set_clock(uint8_t fs_case){
	uint8_t command[2];
	command[0]=3;
	command[1]=255;
	HAL_I2C_Master_Transmit(&hi2c3,clockgen_addr,command,clockgen_command_lenght,HAL_MAX_DELAY);
	command[0]=16;
	command[1]=128;
	HAL_I2C_Master_Transmit(&hi2c3,clockgen_addr,command,clockgen_command_lenght,HAL_MAX_DELAY);
	command[0]=17;
	command[1]=128;
	HAL_I2C_Master_Transmit(&hi2c3,clockgen_addr,command,clockgen_command_lenght,HAL_MAX_DELAY);
	command[0]=18;
	command[1]=128;
	HAL_I2C_Master_Transmit(&hi2c3,clockgen_addr,command,clockgen_command_lenght,HAL_MAX_DELAY);
	command[0]=2;
	command[1]=248;
	HAL_I2C_Master_Transmit(&hi2c3,clockgen_addr,command,clockgen_command_lenght,HAL_MAX_DELAY);
	switch (fs_case){
		case 0:
		for(int i=0;i<clockgen_num_registers;i++){
			command[0]=R44100[i].address;
			command[1]=R44100[i].value;
			HAL_I2C_Master_Transmit(&hi2c3,clockgen_addr,command,clockgen_command_lenght,HAL_MAX_DELAY);
		}
		break;
		case 1:
		for(int i=0;i<clockgen_num_registers;i++){
			command[0]=R48000[i].address;
			command[1]=R48000[i].value;
			HAL_I2C_Master_Transmit(&hi2c3,clockgen_addr,command,clockgen_command_lenght,HAL_MAX_DELAY);
		}
		break;
		case 2:
		for(int i=0;i<clockgen_num_registers;i++){
			command[0]=R88200[i].address;
			command[1]=R88200[i].value;
			HAL_I2C_Master_Transmit(&hi2c3,clockgen_addr,command,clockgen_command_lenght,HAL_MAX_DELAY);
		}
		break;
		case 3:
		for(int i=0;i<clockgen_num_registers;i++){
			command[0]=R96000[i].address;
			command[1]=R96000[i].value;
			HAL_I2C_Master_Transmit(&hi2c3,clockgen_addr,command,clockgen_command_lenght,HAL_MAX_DELAY);
		}
		break;

	}
	command[0]=177;
	command[1]=172;
	HAL_I2C_Master_Transmit(&hi2c3,clockgen_addr,command,clockgen_command_lenght,HAL_MAX_DELAY);
	command[0]=3;
	command[1]=0;
	HAL_I2C_Master_Transmit(&hi2c3,clockgen_addr,command,clockgen_command_lenght,HAL_MAX_DELAY);
}

void HAL_SAI_TxHalfCpltCallback(SAI_HandleTypeDef *hsai){
	memset( &DAC[0],0,NSAMPLE*32);
	xQueueReceiveFromISR(DACQueue,	&DAC[0], pdFALSE);
}

void HAL_SAI_TxCpltCallback(SAI_HandleTypeDef *hsai){
	memset( &DAC[NSAMPLE*8],0,NSAMPLE*32);
	xQueueReceiveFromISR(DACQueue,	&DAC[NSAMPLE*8],  pdFALSE);
}

void process_custom_frame(uint8_t *frame_data)
{
	// __disable_irq();  // Disable interrupts
	if(packet_check(frame_data,p_out->payload)){
		xQueueGenericSend(DACQueue,frame_data+50+14, portMAX_DELAY,queueSEND_TO_BACK);
		//
        // Enable sending
		sending_enabled=1;
	}
	//__enable_irq();  // Re-enable interrupts
}

/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{

  /* USER CODE BEGIN 1 */

  /* USER CODE END 1 */

  /* MPU Configuration--------------------------------------------------------*/
  MPU_Config();

  /* Enable the CPU Cache */

  /* Enable I-Cache---------------------------------------------------------*/
  SCB_EnableICache();

  /* Enable D-Cache---------------------------------------------------------*/
  SCB_EnableDCache();

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */
  HAL_Delay(500);
  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_DMA_Init();
  MX_I2C3_Init();
  MX_SAI1_Init();
  MX_TIM12_Init();
  /* USER CODE BEGIN 2 */
  HAL_TIM_PWM_Start(&htim12, TIM_CHANNEL_1);
  HAL_TIM_PWM_Start(&htim12, TIM_CHANNEL_2);

  TIM12->PSC=500;
  TIM12->CCR1=65535;
  TIM12->CCR2=35000;

  HAL_Delay(500);

  I2C_set_clock(1);
  I2C_init_dac(dac4_addr);
  I2C_init_dac(dac3_addr);
  I2C_init_dac(dac2_addr);
  I2C_init_dac(dac1_addr);
  type=ntohs(ETHLINK);

  HAL_Delay(500);

  /* USER CODE END 2 */

  /* Init scheduler */
  osKernelInitialize();

  /* USER CODE BEGIN RTOS_MUTEX */
  /* add mutexes, ... */
  /* USER CODE END RTOS_MUTEX */

  /* USER CODE BEGIN RTOS_SEMAPHORES */
  /* add semaphores, ... */
  /* USER CODE END RTOS_SEMAPHORES */

  /* USER CODE BEGIN RTOS_TIMERS */

  /* start timers, add new ones, ... */
  /* USER CODE END RTOS_TIMERS */

  /* USER CODE BEGIN RTOS_QUEUES */
  DACQueue = xQueueCreate(16, NSAMPLE*32);
  /* add queues, ... */
  /* USER CODE END RTOS_QUEUES */

  /* Create the thread(s) */
  /* creation of Main_task */
  Main_taskHandle = osThreadNew(StartMainTask, NULL, &Main_task_attributes);

  /* USER CODE BEGIN RTOS_THREADS */
  /* add threads, ... */
  /* USER CODE END RTOS_THREADS */

  /* USER CODE BEGIN RTOS_EVENTS */
  /* add events, ... */
  /* USER CODE END RTOS_EVENTS */

  /* Start scheduler */
  osKernelStart();

  /* We should never get here as control is now taken by the scheduler */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  while (1)
  {
    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */
  }
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Supply configuration update enable
  */
  HAL_PWREx_ConfigSupply(PWR_LDO_SUPPLY);

  /** Configure the main internal regulator output voltage
  */
  __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE1);

  while(!__HAL_PWR_GET_FLAG(PWR_FLAG_VOSRDY)) {}

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSI;
  RCC_OscInitStruct.HSIState = RCC_HSI_DIV1;
  RCC_OscInitStruct.HSICalibrationValue = RCC_HSICALIBRATION_DEFAULT;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSI;
  RCC_OscInitStruct.PLL.PLLM = 4;
  RCC_OscInitStruct.PLL.PLLN = 50;
  RCC_OscInitStruct.PLL.PLLP = 2;
  RCC_OscInitStruct.PLL.PLLQ = 8;
  RCC_OscInitStruct.PLL.PLLR = 2;
  RCC_OscInitStruct.PLL.PLLRGE = RCC_PLL1VCIRANGE_3;
  RCC_OscInitStruct.PLL.PLLVCOSEL = RCC_PLL1VCOWIDE;
  RCC_OscInitStruct.PLL.PLLFRACN = 0;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2
                              |RCC_CLOCKTYPE_D3PCLK1|RCC_CLOCKTYPE_D1PCLK1;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.SYSCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_HCLK_DIV2;
  RCC_ClkInitStruct.APB3CLKDivider = RCC_APB3_DIV2;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_APB1_DIV2;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_APB2_DIV2;
  RCC_ClkInitStruct.APB4CLKDivider = RCC_APB4_DIV2;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_2) != HAL_OK)
  {
    Error_Handler();
  }
}

/**
  * @brief I2C3 Initialization Function
  * @param None
  * @retval None
  */
static void MX_I2C3_Init(void)
{

  /* USER CODE BEGIN I2C3_Init 0 */

  /* USER CODE END I2C3_Init 0 */

  /* USER CODE BEGIN I2C3_Init 1 */

  /* USER CODE END I2C3_Init 1 */
  hi2c3.Instance = I2C3;
  hi2c3.Init.Timing = 0x009034B6;
  hi2c3.Init.OwnAddress1 = 0;
  hi2c3.Init.AddressingMode = I2C_ADDRESSINGMODE_7BIT;
  hi2c3.Init.DualAddressMode = I2C_DUALADDRESS_DISABLE;
  hi2c3.Init.OwnAddress2 = 0;
  hi2c3.Init.OwnAddress2Masks = I2C_OA2_NOMASK;
  hi2c3.Init.GeneralCallMode = I2C_GENERALCALL_DISABLE;
  hi2c3.Init.NoStretchMode = I2C_NOSTRETCH_DISABLE;
  if (HAL_I2C_Init(&hi2c3) != HAL_OK)
  {
    Error_Handler();
  }

  /** Configure Analogue filter
  */
  if (HAL_I2CEx_ConfigAnalogFilter(&hi2c3, I2C_ANALOGFILTER_ENABLE) != HAL_OK)
  {
    Error_Handler();
  }

  /** Configure Digital filter
  */
  if (HAL_I2CEx_ConfigDigitalFilter(&hi2c3, 0) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN I2C3_Init 2 */

  /* USER CODE END I2C3_Init 2 */

}

/**
  * @brief SAI1 Initialization Function
  * @param None
  * @retval None
  */
static void MX_SAI1_Init(void)
{

  /* USER CODE BEGIN SAI1_Init 0 */

  /* USER CODE END SAI1_Init 0 */

  /* USER CODE BEGIN SAI1_Init 1 */

  /* USER CODE END SAI1_Init 1 */
  hsai_BlockA1.Instance = SAI1_Block_A;
  hsai_BlockA1.Init.Protocol = SAI_FREE_PROTOCOL;
  hsai_BlockA1.Init.AudioMode = SAI_MODESLAVE_TX;
  hsai_BlockA1.Init.DataSize = SAI_DATASIZE_32;
  hsai_BlockA1.Init.FirstBit = SAI_FIRSTBIT_MSB;
  hsai_BlockA1.Init.ClockStrobing = SAI_CLOCKSTROBING_RISINGEDGE;
  hsai_BlockA1.Init.Synchro = SAI_ASYNCHRONOUS;
  hsai_BlockA1.Init.OutputDrive = SAI_OUTPUTDRIVE_ENABLE;
  hsai_BlockA1.Init.FIFOThreshold = SAI_FIFOTHRESHOLD_EMPTY;
  hsai_BlockA1.Init.SynchroExt = SAI_SYNCEXT_DISABLE;
  hsai_BlockA1.Init.MonoStereoMode = SAI_STEREOMODE;
  hsai_BlockA1.Init.CompandingMode = SAI_NOCOMPANDING;
  hsai_BlockA1.Init.TriState = SAI_OUTPUT_NOTRELEASED;
  hsai_BlockA1.Init.PdmInit.Activation = DISABLE;
  hsai_BlockA1.Init.PdmInit.MicPairsNbr = 1;
  hsai_BlockA1.Init.PdmInit.ClockEnable = SAI_PDM_CLOCK1_ENABLE;
  hsai_BlockA1.FrameInit.FrameLength = 256;
  hsai_BlockA1.FrameInit.ActiveFrameLength = 128;
  hsai_BlockA1.FrameInit.FSDefinition = SAI_FS_STARTFRAME;
  hsai_BlockA1.FrameInit.FSPolarity = SAI_FS_ACTIVE_HIGH;
  hsai_BlockA1.FrameInit.FSOffset = SAI_FS_FIRSTBIT;
  hsai_BlockA1.SlotInit.FirstBitOffset = 0;
  hsai_BlockA1.SlotInit.SlotSize = SAI_SLOTSIZE_32B;
  hsai_BlockA1.SlotInit.SlotNumber = 8;
  hsai_BlockA1.SlotInit.SlotActive = 0x0000FFFF;
  if (HAL_SAI_Init(&hsai_BlockA1) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN SAI1_Init 2 */

  /* USER CODE END SAI1_Init 2 */

}

/**
  * @brief TIM12 Initialization Function
  * @param None
  * @retval None
  */
static void MX_TIM12_Init(void)
{

  /* USER CODE BEGIN TIM12_Init 0 */

  /* USER CODE END TIM12_Init 0 */

  TIM_MasterConfigTypeDef sMasterConfig = {0};
  TIM_OC_InitTypeDef sConfigOC = {0};

  /* USER CODE BEGIN TIM12_Init 1 */

  /* USER CODE END TIM12_Init 1 */
  htim12.Instance = TIM12;
  htim12.Init.Prescaler = 0;
  htim12.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim12.Init.Period = 65535;
  htim12.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim12.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
  if (HAL_TIM_PWM_Init(&htim12) != HAL_OK)
  {
    Error_Handler();
  }
  sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&htim12, &sMasterConfig) != HAL_OK)
  {
    Error_Handler();
  }
  sConfigOC.OCMode = TIM_OCMODE_PWM1;
  sConfigOC.Pulse = 0;
  sConfigOC.OCPolarity = TIM_OCPOLARITY_HIGH;
  sConfigOC.OCFastMode = TIM_OCFAST_DISABLE;
  if (HAL_TIM_PWM_ConfigChannel(&htim12, &sConfigOC, TIM_CHANNEL_1) != HAL_OK)
  {
    Error_Handler();
  }
  if (HAL_TIM_PWM_ConfigChannel(&htim12, &sConfigOC, TIM_CHANNEL_2) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN TIM12_Init 2 */

  /* USER CODE END TIM12_Init 2 */
  HAL_TIM_MspPostInit(&htim12);

}

/**
  * Enable DMA controller clock
  */
static void MX_DMA_Init(void)
{

  /* DMA controller clock enable */
  __HAL_RCC_DMA1_CLK_ENABLE();

  /* DMA interrupt init */
  /* DMA1_Stream0_IRQn interrupt configuration */
  HAL_NVIC_SetPriority(DMA1_Stream0_IRQn, 5, 0);
  HAL_NVIC_EnableIRQ(DMA1_Stream0_IRQn);

}

/**
  * @brief GPIO Initialization Function
  * @param None
  * @retval None
  */
static void MX_GPIO_Init(void)
{
  GPIO_InitTypeDef GPIO_InitStruct = {0};
/* USER CODE BEGIN MX_GPIO_Init_1 */
/* USER CODE END MX_GPIO_Init_1 */

  /* GPIO Ports Clock Enable */
  __HAL_RCC_GPIOE_CLK_ENABLE();
  __HAL_RCC_GPIOC_CLK_ENABLE();
  __HAL_RCC_GPIOA_CLK_ENABLE();
  __HAL_RCC_GPIOB_CLK_ENABLE();

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(ETH_RESET_GPIO_Port, ETH_RESET_Pin, GPIO_PIN_SET);

  /*Configure GPIO pin : ETH_RESET_Pin */
  GPIO_InitStruct.Pin = ETH_RESET_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_OD;
  GPIO_InitStruct.Pull = GPIO_PULLUP;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_VERY_HIGH;
  HAL_GPIO_Init(ETH_RESET_GPIO_Port, &GPIO_InitStruct);

/* USER CODE BEGIN MX_GPIO_Init_2 */
/* USER CODE END MX_GPIO_Init_2 */
}

/* USER CODE BEGIN 4 */

/* USER CODE END 4 */

/* USER CODE BEGIN Header_StartMainTask */
/**
  * @brief  Function implementing the Main_task thread.
  * @param  argument: Not used
  * @retval None
  */
/* USER CODE END Header_StartMainTask */
void StartMainTask(void *argument)
{
  /* init code for LWIP */
  MX_LWIP_Init();
  /* USER CODE BEGIN 5 */
  // Allocate a pbuf for the Ethernet frame (Ethernet header + payload)
  p_out = pbuf_alloc(PBUF_RAW,50+14, PBUF_RAM);
  memset(p_out->payload,250,50+14);
  htim12.Instance->PSC = 0;
  /* Infinite loop */
  for(;;)
  {
    osDelay(configTICK_RATE_HZ);

    if(sending_enabled){
        // Send the packet using the low-level Ethernet driver
        if(netif_is_link_up(&gnetif)){
        	gnetif.linkoutput(&gnetif, p_out);
       	}
    	TIM12->CCR1=0;
    	sending_enabled=0;
    }else{
    	TIM12->CCR1=65535;
    }
  }
  /* USER CODE END 5 */
}

 /* MPU Configuration */

void MPU_Config(void)
{
  MPU_Region_InitTypeDef MPU_InitStruct = {0};

  /* Disables the MPU */
  HAL_MPU_Disable();

  /** Initializes and configures the Region and the memory to be protected
  */
  MPU_InitStruct.Enable = MPU_REGION_ENABLE;
  MPU_InitStruct.Number = MPU_REGION_NUMBER0;
  MPU_InitStruct.BaseAddress = 0x0;
  MPU_InitStruct.Size = MPU_REGION_SIZE_4GB;
  MPU_InitStruct.SubRegionDisable = 0x87;
  MPU_InitStruct.TypeExtField = MPU_TEX_LEVEL0;
  MPU_InitStruct.AccessPermission = MPU_REGION_NO_ACCESS;
  MPU_InitStruct.DisableExec = MPU_INSTRUCTION_ACCESS_DISABLE;
  MPU_InitStruct.IsShareable = MPU_ACCESS_SHAREABLE;
  MPU_InitStruct.IsCacheable = MPU_ACCESS_NOT_CACHEABLE;
  MPU_InitStruct.IsBufferable = MPU_ACCESS_NOT_BUFFERABLE;

  HAL_MPU_ConfigRegion(&MPU_InitStruct);

  /** Initializes and configures the Region and the memory to be protected
  */
  MPU_InitStruct.Number = MPU_REGION_NUMBER1;
  MPU_InitStruct.BaseAddress = 0x30000000;
  MPU_InitStruct.Size = MPU_REGION_SIZE_128KB;
  MPU_InitStruct.SubRegionDisable = 0x0;
  MPU_InitStruct.TypeExtField = MPU_TEX_LEVEL1;
  MPU_InitStruct.AccessPermission = MPU_REGION_FULL_ACCESS;
  MPU_InitStruct.IsShareable = MPU_ACCESS_NOT_SHAREABLE;

  HAL_MPU_ConfigRegion(&MPU_InitStruct);

  /** Initializes and configures the Region and the memory to be protected
  */
  MPU_InitStruct.Number = MPU_REGION_NUMBER2;
  MPU_InitStruct.BaseAddress = 0x30020000;
  MPU_InitStruct.Size = MPU_REGION_SIZE_256B;
  MPU_InitStruct.TypeExtField = MPU_TEX_LEVEL0;
  MPU_InitStruct.IsShareable = MPU_ACCESS_SHAREABLE;
  MPU_InitStruct.IsBufferable = MPU_ACCESS_BUFFERABLE;

  HAL_MPU_ConfigRegion(&MPU_InitStruct);

  /** Initializes and configures the Region and the memory to be protected
  */
  MPU_InitStruct.Number = MPU_REGION_NUMBER3;
  MPU_InitStruct.BaseAddress = 0x38000000;
  MPU_InitStruct.Size = MPU_REGION_SIZE_64KB;
  MPU_InitStruct.DisableExec = MPU_INSTRUCTION_ACCESS_ENABLE;
  MPU_InitStruct.IsCacheable = MPU_ACCESS_CACHEABLE;
  MPU_InitStruct.IsBufferable = MPU_ACCESS_NOT_BUFFERABLE;

  HAL_MPU_ConfigRegion(&MPU_InitStruct);
  /* Enables the MPU */
  HAL_MPU_Enable(MPU_PRIVILEGED_DEFAULT);

}

/**
  * @brief  Period elapsed callback in non blocking mode
  * @note   This function is called  when TIM6 interrupt took place, inside
  * HAL_TIM_IRQHandler(). It makes a direct call to HAL_IncTick() to increment
  * a global variable "uwTick" used as application time base.
  * @param  htim : TIM handle
  * @retval None
  */
void HAL_TIM_PeriodElapsedCallback(TIM_HandleTypeDef *htim)
{
  /* USER CODE BEGIN Callback 0 */

  /* USER CODE END Callback 0 */
  if (htim->Instance == TIM6) {
    HAL_IncTick();
  }
  /* USER CODE BEGIN Callback 1 */

  /* USER CODE END Callback 1 */
}

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
